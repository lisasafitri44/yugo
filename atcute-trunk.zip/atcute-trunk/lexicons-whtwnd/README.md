https://github.com/whtwnd/whitewind-blog/tree/dc4b802154250b982191a52af1d1c9913c3b62e7/lexicons
