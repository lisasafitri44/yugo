https://github.com/aendra-rininsland/bluemoji/tree/802a236415645e765a40fb02b6dc1e04344058f5/schema
