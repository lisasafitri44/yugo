https://github.com/mary-ext/tangled.sh-mirror/tree/86daf8e3a3304bed263606faa6aa7b9941fbad72/lexicons
