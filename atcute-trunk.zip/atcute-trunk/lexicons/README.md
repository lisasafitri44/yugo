https://github.com/bluesky-social/atproto/tree/3a65b68f7dc63c8bfbea0ae615f8ae984272f2e4/lexicons
