---
'@atcute/lexicons': patch
---

avoid missing key check if optional
