---
'@atcute/lexicons': patch
---

avoid in operator when validating variants
