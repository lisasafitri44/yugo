---
'@atcute/uint8array': patch
---

attempt fast-path ASCII-only decoding for small strings
