---
'@atcute/lexicons': patch
---

attempt ASCII-only fast-path for UTF-8 length checking
