# @atcute/bluesky-moderation

## 2.0.0

### Patch Changes

- Updated dependencies [d02554d]
- Updated dependencies [af85dca]
  - @atcute/bluesky@3.0.0
