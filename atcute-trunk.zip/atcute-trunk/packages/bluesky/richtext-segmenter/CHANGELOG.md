# @atcute/bluesky-richtext-segmenter

## 2.0.1

### Patch Changes

- Updated dependencies [d02554d]
- Updated dependencies [af85dca]
  - @atcute/bluesky@3.0.0

## 2.0.0

### Patch Changes

- Updated dependencies [9d05dfd]
- Updated dependencies [ecce2c6]
- Updated dependencies [13f35e4]
- Updated dependencies [a47373f]
- Updated dependencies [45cc699]
- Updated dependencies [2d10bd8]
- Updated dependencies [8aedcc5]
- Updated dependencies [45cfe46]
- Updated dependencies [813679f]
- Updated dependencies [24be9be]
- Updated dependencies [d3fbc7e]
- Updated dependencies [c7e8573]
- Updated dependencies [61bd8d2]
- Updated dependencies [87a99f1]
  - @atcute/client@3.0.0
  - @atcute/bluesky@2.0.0
